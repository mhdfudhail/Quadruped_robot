# Hexapod_Robot
## Inversekinematics for one leg with 3DOF
Explanation video can be found on my YouTube channel: https://youtu.be/2edpf6fNoso

Change the leg length variables to use; the default is 10 for coxa, femur and tibia. It should work in any units, including m, mm, inch, etc. 

![image](https://user-images.githubusercontent.com/75647798/124458870-a1640980-dde1-11eb-9818-751332c7d57f.png)
![image7](https://user-images.githubusercontent.com/75647798/124765466-18d49d00-df8a-11eb-94f5-0c86b79ffa94.jpg)

